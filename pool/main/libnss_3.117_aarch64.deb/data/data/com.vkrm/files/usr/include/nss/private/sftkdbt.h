/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

#ifndef SFTKDBT_H
#define SFTKDBT_H 1
typedef struct SFTKDBHandleStr SFTKDBHandle;

#define SDB_MAX_META_DATA_LEN 256
#define SDB_ULONG_SIZE 4

#endif
