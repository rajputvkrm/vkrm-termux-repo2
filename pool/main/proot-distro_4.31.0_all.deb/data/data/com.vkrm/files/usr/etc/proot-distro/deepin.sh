# This is a default distribution plug-in.
# Do not modify this file as your changes will be overwritten on next update.
# If you want customize installation, please make a copy.
DISTRO_NAME="deepin"

TARBALL_URL['aarch64']="https://github.com/termux/proot-distro/releases/download/v4.29.0/deepin-aarch64-pd-v4.29.0.tar.xz"
TARBALL_SHA256['aarch64']="3ed17c2fa45c8fd00468378e1f140af5ce6b6f633f986b2d1ae0e81d68eefb64"
TARBALL_URL['x86_64']="https://github.com/termux/proot-distro/releases/download/v4.29.0/deepin-x86_64-pd-v4.29.0.tar.xz"
TARBALL_SHA256['x86_64']="b859e83eaf6a54b14579e8e06231056f75c73fec7332e20a1596dc3122048b3e"
